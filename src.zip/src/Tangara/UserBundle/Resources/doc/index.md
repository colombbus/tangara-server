Getting Started With TangaraUI
==================================

The TangaraUI component provides a flexible framework that
allows you to load users from configuration, a database, or anywhere else
you can imagine for the TangaraJS project. This project aims to be the first 
educational programming that permits work on project : youngs can work together !


## Prerequisites


### Translations

## Installation

Installation is a quick (I promise!) 7 step process:

1. Download TangaraUI using composer

### Step 1: 

``` yml

```

### Next Steps

Now that you have completed the basic installation and configuration of the
FOSUserBundle, you are ready to learn about more advanced features and usages
of the bundle.

The following documents are available:

- [Overriding Templates](overriding_templates.md)
