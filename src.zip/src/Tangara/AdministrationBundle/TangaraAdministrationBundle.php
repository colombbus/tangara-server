<?php

namespace Tangara\AdministrationBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TangaraAdministrationBundle extends Bundle
{
}
