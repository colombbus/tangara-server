<?php

namespace Tangara\TangaraBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TangaraTangaraBundle extends Bundle
{
}
