<?php

namespace Tangara\ProjectBundle\Tests\Controller;

class PhpunitTest extends \PHPUnit_Framework_TestCase
{
    public function testPhpunit()
    {
        $this->assertTrue(true);
    }
}
