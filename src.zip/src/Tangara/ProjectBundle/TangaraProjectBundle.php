<?php

namespace Tangara\ProjectBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TangaraProjectBundle extends Bundle
{
}
